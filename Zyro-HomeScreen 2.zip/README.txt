ZYRO HOME SCREEN VERSION

1. Put these files on a web host that provides HTTPS.
2. On your iPhone, open the site's index.html through Safari.
3. Tap the Share button.
4. Choose "Add to Home Screen".
5. Name it Zyro and tap Add.

Important: iOS requires the site to be served over HTTPS for a reliable web-app experience. A local HTML file cannot be turned into a normal Home Screen web app just by opening it from Files.
