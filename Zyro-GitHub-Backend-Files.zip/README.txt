ZYRO — GitHub + Render setup

Upload index.html, server.js, and package.json to the ROOT of your existing GitHub repository. Replace the old index.html with this updated one. Keep your existing manifest.webmanifest.

Render Web Service:
- Runtime/Language: Node
- Build Command: npm install
- Start Command: npm start
- Environment Variable key: GROQ_API_KEY
- Environment Variable value: your private Groq API key

Never add your API key to GitHub or index.html.

After committing files, Render should redeploy the linked repository. Check Render logs if deployment fails.

Notes:
- Chat is not unlimited; Groq has its own usage limits and availability.
- Images and Videos currently help draft prompts; they do not generate actual image/video files.
- Requires Node.js 18 or newer.
