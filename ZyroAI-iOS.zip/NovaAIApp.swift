import SwiftUI

@main
struct ZyroAIApp: App {
    var body: some Scene {
        WindowGroup {
            ZyroRootView()
        }
    }
}
